<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>รายการเพลง</title>
    <link rel="stylesheet" href="style.css?v=<?= time(); ?>">
    <?php echo '<!-- CSS loaded with version: ' . filemtime('style.css') . ' -->'; ?>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
<?php include 'nav.php' ; ?>

    <h1>🎵 รายการเพลง</h1>
    <?php
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $sql = "SELECT * FROM songs";
    if (!empty($search)) {
        $search = $conn->real_escape_string($search);
        $sql .= " WHERE title LIKE '%$search%'";
    }
    $result = $conn->query($sql);
    if ($result->num_rows > 0):
        while ($row = $result->fetch_assoc()):
    ?>
        <div class="song">
            <h3><?php echo htmlspecialchars($row['title']); ?></h3>
            <audio controls>
                <source src="music/<?php echo htmlspecialchars($row['filename']); ?>" type="audio/mpeg">
            </audio>
        </div>
    <?php endwhile; else: ?>
        <p>ไม่พบเพลงในระบบ</p>
    <?php endif; ?>
    <p><a href="upload.php">➕ อัปโหลดเพลงใหม่</a></p>
</body>
</html>