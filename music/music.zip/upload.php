<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>อัปโหลดเพลง</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>📤 อัปโหลดเพลงใหม่</h1>
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="ชื่อเพลง" required>
        <input type="file" name="file" accept=".mp3" required>
        <button type="submit" name="upload">อัปโหลด</button>
    </form>
    <?php
    if (isset($_POST['upload'])) {
        $title = $_POST['title'];
        $file = $_FILES['file'];

        // ตั้งชื่อไฟล์ใหม่ ป้องกันภาษาไทย/ช่องว่าง
        $safeName = time() . "_" . preg_replace("/[^a-zA-Z0-9\.]/", "_", $file['name']);
        $target = "music" . $safeName;

        if (move_uploaded_file($file['tmp_name'], $target)) {
            $stmt = $conn->prepare("INSERT INTO songs (title, filename) VALUES (?, ?)");
            $stmt->bind_param("ss", $title, $safeName);
            $stmt->execute();
            echo "<p>✅ อัปโหลดสำเร็จ!</p>";
        } else {
            echo "<p>❌ เกิดข้อผิดพลาดในการอัปโหลดไฟล์</p>";
        }
    }
    ?>
    <p><a href="index.php">🔙 กลับไปหน้าเพลง</a></p>
</body>
</html>